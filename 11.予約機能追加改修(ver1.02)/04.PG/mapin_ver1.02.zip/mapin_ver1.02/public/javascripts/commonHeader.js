// 共通
window.onload = function() {
	$('header').load('/htmls/header.html');
}