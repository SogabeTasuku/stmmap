window.onload = function() {
	// 共通処理（リンク設定）
	// linkSetting(['logout_link', 'reserveList_link']);
}
